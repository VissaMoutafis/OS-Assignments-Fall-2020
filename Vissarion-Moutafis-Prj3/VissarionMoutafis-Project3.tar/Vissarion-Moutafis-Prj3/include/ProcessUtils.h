#pragma once

#include "Types.h"

// common functions that is used for process work-flow and IPC

// wait for children to end
void wait_children(void);