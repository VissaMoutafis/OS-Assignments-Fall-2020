#pragma once

#include <stdio.h>
#include "Types.h"
#include "ProcessUtils.h"
#include "SharedSeg.h"
#include "Sem.h"

#define MAX_PREP_TIME 5
