#include "Process.h"
#include "ParsingUtils.h"
#include <time.h>

static char *posible_algos[] = {
    "./primes1",
    "./primes2",
    "./primes3",
};

void read_from_child(int **fd_array, int number_of_children) {
    struct pollfd fds[number_of_children];
    
    //set up the fds array
    for (int i = 0; i < number_of_children; i++) {
        fds[i].events = POLLIN;
        fds[i].fd = fd_array[i][READ];
        fds[i].revents = 0;
    }

    while(true) {
        // call the poll syscall
        int retpoll = poll(fds, number_of_children, TIMEOUT);

        if (retpoll > 0) {
            for (int i = 0; i < number_of_children; i++)
                if (fds[i].revents & POLLIN) // if the file descriptor is in the ready list
                    print_primes_from_child(fds[i].fd); // print what's in there
        } else if (retpoll < 0) {
            perror("poll");
            exit(1);
        }
    }
}

// argv = min, max, algorithm index
int main(int argc, char* argv[]) {
    srand(time(NULL));
    if (argc != 7) {
        fprintf(stderr, "Wrong input! ./workers -l min -u max -algo algo num\n");
        exit(1);
    }
    if( !( is_numeric(argv[2]) && is_numeric(argv[4]) && is_numeric(argv[6])) ) {
        fprintf(stderr, "All args must be numeric.\n");
        exit(1);
    }
    if(!(atoi(argv[6]) <= PRIME_ALGOS)) {
        fprintf(stderr, "The algorithm inedx must be between 0 and %d.\n", PRIME_ALGOS-1);
        exit(1);
    }

    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(1);
    }

    // close the pipe write-end for parent
    close(fd[WRITE]);

    pid_t child_pid = fork();
    if (child_pid == -1) {
        perror("fork");
        exit(1);
    }
    
    if(child_pid == 0) {
        // child case
        
        // close the pipe read-end for child
        close(fd[READ]);

        // choose the algorithm
        char *bin_path = posible_algos[atoi(argv[6])];
        char *args[] = {bin_path, argv[2], argv[4], (char *)0};
        //execute the program
        if (execvp(bin_path, args) == -1) {
            perror("execvp()");
            exit(1);
        }
    }

    // wait for the child to end
    if (child_pid == wait(NULL))
        read_from_child(&fd);
    else {
        perror("wait for prime algo");
        exit(1);
    } 

    kill(getppid(), SIGUSR1); //send sigusr1 signal to the parent
    exit(0);
}